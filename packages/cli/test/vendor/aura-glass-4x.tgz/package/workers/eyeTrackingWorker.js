"use strict";
(() => {
  let isTracking = false;
  let processingInterval = null;
  function processEyeTracking(frame) {
    const timestamp = Date.now();
    const baseX = 0.5 + Math.sin(timestamp / 1e3) * 0.2;
    const baseY = 0.5 + Math.cos(timestamp / 1500) * 0.2;
    const x = Math.max(0, Math.min(1, baseX + (Math.random() - 0.5) * 0.05));
    const y = Math.max(0, Math.min(1, baseY + (Math.random() - 0.5) * 0.05));
    return {
      x,
      y,
      confidence: 0.85 + Math.random() * 0.15,
      // 85-100% confidence
      timestamp
    };
  }
  self.addEventListener("message", (event) => {
    const { command, data } = event.data;
    switch (command) {
      case "start":
        isTracking = true;
        processingInterval = setInterval(() => {
          if (isTracking) {
            const gazeData = processEyeTracking();
            self.postMessage(gazeData);
          }
        }, 16.67);
        self.postMessage({ status: "started" });
        break;
      case "stop":
        isTracking = false;
        if (processingInterval) {
          clearInterval(processingInterval);
          processingInterval = null;
        }
        self.postMessage({ status: "stopped" });
        break;
      case "process":
        if (data?.videoFrame) {
          const gazeData = processEyeTracking(data.videoFrame);
          self.postMessage(gazeData);
        }
        break;
      default:
        self.postMessage({ error: "Unknown command" });
    }
  });
  self.postMessage({ status: "ready" });
})();
//# sourceMappingURL=eyeTrackingWorker.js.map
