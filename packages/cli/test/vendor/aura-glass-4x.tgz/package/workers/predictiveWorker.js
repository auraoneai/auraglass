"use strict";
(() => {
  function analyzePatternsAndPredict(patterns) {
    if (patterns.length === 0) {
      return {
        predictions: [],
        confidence: 0,
        patterns: {
          mostCommonAction: "none",
          averageSessionDuration: 0,
          engagementScore: 0
        },
        recommendations: []
      };
    }
    const actionCounts = /* @__PURE__ */ new Map();
    const actionSequences = [];
    patterns.forEach((pattern) => {
      const action = `${pattern.type}:${pattern.target || "unknown"}`;
      actionCounts.set(action, (actionCounts.get(action) || 0) + 1);
      actionSequences.push(action);
    });
    let mostCommonAction = "none";
    let maxCount = 0;
    actionCounts.forEach((count, action) => {
      if (count > maxCount) {
        maxCount = count;
        mostCommonAction = action;
      }
    });
    const sessionStart = patterns[0].timestamp;
    const sessionEnd = patterns[patterns.length - 1].timestamp;
    const averageSessionDuration = sessionEnd - sessionStart;
    const interactionRate = patterns.length / (averageSessionDuration / 1e3) * 60;
    const engagementScore = Math.min(1, interactionRate / 20);
    const predictions = [];
    const recentPatterns = patterns.slice(-5);
    const recentSequence = recentPatterns.map(
      (p) => `${p.type}:${p.target || "unknown"}`
    );
    const sequenceMap = /* @__PURE__ */ new Map();
    for (let i = 0; i < actionSequences.length - 1; i++) {
      const current = actionSequences[i];
      const next = actionSequences[i + 1];
      if (!sequenceMap.has(current)) {
        sequenceMap.set(current, /* @__PURE__ */ new Map());
      }
      const nextMap = sequenceMap.get(current);
      nextMap.set(next, (nextMap.get(next) || 0) + 1);
    }
    const lastAction = actionSequences[actionSequences.length - 1];
    const nextActionMap = sequenceMap.get(lastAction);
    if (nextActionMap) {
      const totalNext = Array.from(nextActionMap.values()).reduce(
        (sum, count) => sum + count,
        0
      );
      nextActionMap.forEach((count, action) => {
        const confidence = count / totalNext;
        if (confidence > 0.2) {
          predictions.push({
            action: action.replace(":", " on "),
            confidence,
            suggestedOptimization: generateOptimization(action, confidence)
          });
        }
      });
    }
    predictions.sort((a, b) => b.confidence - a.confidence);
    const recommendations = [];
    if (engagementScore < 0.3) {
      recommendations.push(
        "Low engagement detected. Consider adding interactive elements."
      );
    }
    if (engagementScore > 0.8) {
      recommendations.push(
        "High engagement! Current UX patterns are working well."
      );
    }
    const repetitiveActions = Array.from(actionCounts.entries()).filter(
      ([_, count]) => count > patterns.length * 0.3
    );
    if (repetitiveActions.length > 0) {
      recommendations.push(
        `Repetitive action detected: ${repetitiveActions[0][0]}. User may be stuck or confused.`
      );
    }
    const scrollCount = patterns.filter((p) => p.type === "scroll").length;
    if (scrollCount > patterns.length * 0.5) {
      recommendations.push(
        "High scroll rate. Consider improving content visibility or adding sticky navigation."
      );
    }
    return {
      predictions: predictions.slice(0, 3),
      // Top 3 predictions
      confidence: predictions.length > 0 ? predictions[0].confidence : 0,
      patterns: {
        mostCommonAction,
        averageSessionDuration,
        engagementScore
      },
      recommendations
    };
  }
  function generateOptimization(action, confidence) {
    if (confidence > 0.7) {
      return `Preload resources for "${action}" (high confidence)`;
    } else if (confidence > 0.5) {
      return `Consider prefetching data for "${action}"`;
    } else {
      return `Monitor pattern for "${action}"`;
    }
  }
  self.addEventListener("message", (event) => {
    const { patterns } = event.data;
    if (patterns && Array.isArray(patterns)) {
      const result = analyzePatternsAndPredict(patterns);
      self.postMessage(result);
    } else {
      self.postMessage({
        predictions: [],
        confidence: 0,
        patterns: {
          mostCommonAction: "none",
          averageSessionDuration: 0,
          engagementScore: 0
        },
        recommendations: ["No pattern data provided"]
      });
    }
  });
  self.postMessage({ status: "ready" });
})();
//# sourceMappingURL=predictiveWorker.js.map
